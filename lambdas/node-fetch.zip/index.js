import fetch from 'node-fetch';

export const handler = async (event) => {
  try {
    const lat = 35.9606; // Knoxville latitude
    const lng = -83.9207; // Knoxville longitude
    
    // Fetch today's data
    const todayResponse = await fetch(`https://api.sunrisesunset.io/json?lat=${lat}&lng=${lng}`);
    const todayData = await todayResponse.json();

    // Fetch tomorrow's data
    const tomorrowResponse = await fetch(`https://api.sunrisesunset.io/json?lat=${lat}&lng=${lng}&date=tomorrow`);
    const tomorrowData = await tomorrowResponse.json();

    // Prepare the response object
    const response = {
      statusCode: 200,
      body: JSON.stringify({
        today: todayData.status === "OK" ? todayData.results : { error: todayData.status },
        tomorrow: tomorrowData.status === "OK" ? tomorrowData.results : { error: tomorrowData.status },
      }),
    };
    return response;
    
  } catch (error) {
    console.error("Error fetching data:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error' }),
    };
  }
};
